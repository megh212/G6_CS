#This code uses the Fernet symmetric key encryption scheme from the cryptography library. 
# It generates a key, encrypts the text, and then decrypts it. 
# Make sure to keep the generated key secret, as it's needed for both encryption and decryption.
from cryptography.fernet import Fernet

def generate_key():
    return Fernet.generate_key()

def encrypt_text(key, text):
    cipher_suite = Fernet(key)
    encrypted_text = cipher_suite.encrypt(text.encode('utf-8'))
    return encrypted_text

def decrypt_text(key, encrypted_text):
    cipher_suite = Fernet(key)
    decrypted_text = cipher_suite.decrypt(encrypted_text).decode('utf-8')
    return decrypted_text

# Example usage:
# Generate a key (keep this key secret)
secret_key = generate_key()

# Text to encrypt
text_to_encrypt = "Hello, this is a secret message!"

# Encrypt the text
encrypted_text = encrypt_text(secret_key, text_to_encrypt)
print("Encrypted Text:", encrypted_text)

# Decrypt the text
decrypted_text = decrypt_text(secret_key, encrypted_text)
print("Decrypted Text:", decrypted_text)
